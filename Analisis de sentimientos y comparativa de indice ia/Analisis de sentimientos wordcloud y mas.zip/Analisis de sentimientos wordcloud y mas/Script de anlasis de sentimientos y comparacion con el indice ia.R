# ==============================================================================
# SCRIPT COMPLETO DE ANÁLISIS DE TEXTO Y SENTIMIENTOS (STEAM Y OPENCRITIC)
# ==============================================================================

# ------------------------------------------------------------------------------
# 0. INSTALACIÓN Y CARGA DE PAQUETES
# ------------------------------------------------------------------------------

install.packages(c("tidyverse", "tm", "SnowballC", "wordcloud", "RColorBrewer", "syuzhet"))



library(tidyverse)
library(stringr)
library(tm)
library(SnowballC)
library(wordcloud)
library(RColorBrewer)
library(syuzhet)

# Definir palabras vacías (stopwords) personalizadas para mejorar ambos análisis
# Nota: Si las reseñas de Steam siguen en inglés, cambia stopwords("es") por stopwords("en")
mis_stopwords <- c(
  stopwords("es"),
  "juego", "juegos", "steam", "review", "reseña",
  "muy", "solo", "puede", "hacer", "ser", "si", "tan",
  "cada", "aunque", "aun", "tener", "red", "dead", 
  "redemption"
)

# ==============================================================================
# 1. ANÁLISIS DE RESEÑAS STEAM
# ==============================================================================

# 1.1 Leer archivo 
steam <- read.csv("tabla_analisis_ia.csv", stringsAsFactors = FALSE)

# 1.2 Limpieza del texto
corpus_steam <- VCorpus(VectorSource(steam$review))
corpus_steam <- tm_map(corpus_steam, content_transformer(tolower))
corpus_steam <- tm_map(corpus_steam, removePunctuation)
corpus_steam <- tm_map(corpus_steam, removeNumbers)
corpus_steam <- tm_map(corpus_steam, removeWords, mis_stopwords) # Aplicando lista mejorada
corpus_steam <- tm_map(corpus_steam, stripWhitespace)

# 1.3 Nube de palabras
dtm_steam <- TermDocumentMatrix(corpus_steam)
m_steam <- as.matrix(dtm_steam)
frecuencia_steam <- sort(rowSums(m_steam), decreasing = TRUE)

wordcloud(
  words = names(frecuencia_steam),
  freq = frecuencia_steam,
  min.freq = 3,
  max.words = 150,
  random.order = FALSE,
  colors = brewer.pal(8, "Dark2")
)

# 1.4 Top 20 Palabras
top_steam <- data.frame(
  Palabra = names(frecuencia_steam),
  Frecuencia = frecuencia_steam
)
head(top_steam, 20)

# 1.5 Gráfico Top 20
ggplot(top_steam[1:20, ], aes(reorder(Palabra, Frecuencia), Frecuencia)) +
  geom_col(fill = "steelblue") +
  coord_flip() +
  labs(
    title = "20 palabras más frecuentes - Steam",
    x = "Palabra",
    y = "Frecuencia"
  )

# 1.6 Análisis de Sentimientos
steam$sentimiento <- get_sentiment(steam$review, method = "syuzhet")
steam$clase <- ifelse(
  steam$sentimiento > 0, "Positivo",
  ifelse(steam$sentimiento < 0, "Negativo", "Neutral")
)
table(steam$clase)

# 1.7 Gráfico Sentimientos
ggplot(steam, aes(clase, fill = clase)) +
  geom_bar() +
  labs(
    title = "Sentimientos de las reseñas de Steam",
    x = "Sentimiento",
    y = "Cantidad"
  )

# 1.8 Emociones NRC
emociones_steam <- get_nrc_sentiment(steam$review)
totales_steam <- colSums(emociones_steam)

# Cambiar nombres a español (manteniendo el orden de NRC)
names(totales_steam) <- c("Ira", "Anticipación", "Asco", "Miedo", "Alegría", 
                          "Tristeza", "Sorpresa", "Confianza", "Negativo", "Positivo")

par(mar = c(5, 7, 4, 2)) 
barplot(
  totales_steam,
  horiz = TRUE,       
  las = 1,             
  col = "skyblue",
  main = "Emociones detectadas en Steam",
  xlab = "Frecuencia"
)
# ==============================================================================
# 2. ANÁLISIS DE OPENCRITIC
# ==============================================================================

# 2.1 Leer archivo
opencritic <- read.csv("tabla_metricas_resenas_traducido.csv", stringsAsFactors = FALSE)

# 2.2 Limpieza del texto
corpus_oc <- VCorpus(VectorSource(opencritic$comentario_traducida))
corpus_oc <- tm_map(corpus_oc, content_transformer(tolower))
corpus_oc <- tm_map(corpus_oc, removePunctuation)
corpus_oc <- tm_map(corpus_oc, removeNumbers)
corpus_oc <- tm_map(corpus_oc, removeWords, mis_stopwords) # Aplicando lista mejorada
corpus_oc <- tm_map(corpus_oc, stripWhitespace)

# 2.3 Nube de palabras
dtm_oc <- TermDocumentMatrix(corpus_oc)
m_oc <- as.matrix(dtm_oc)
frecuencia_oc <- sort(rowSums(m_oc), decreasing = TRUE)

wordcloud(
  words = names(frecuencia_oc),
  freq = frecuencia_oc,
  min.freq = 2,
  max.words = 150,
  random.order = FALSE,
  colors = brewer.pal(8, "Set1")
)

# 2.4 Top 20 Palabras
top_oc <- data.frame(
  Palabra = names(frecuencia_oc),
  Frecuencia = frecuencia_oc
)
head(top_oc, 20)

# 2.5 Gráfico Top 20
ggplot(top_oc[1:20, ], aes(reorder(Palabra, Frecuencia), Frecuencia)) +
  geom_col(fill = "darkgreen") +
  coord_flip() +
  labs(
    title = "20 palabras más frecuentes - OpenCritic",
    x = "Palabra",
    y = "Frecuencia"
  )

# 2.6 Análisis de Sentimientos
opencritic$sentimiento <- get_sentiment(opencritic$comentario_traducida, method = "syuzhet")
opencritic$clase <- ifelse(
  opencritic$sentimiento > 0, "Positivo",
  ifelse(opencritic$sentimiento < 0, "Negativo", "Neutral")
)
table(opencritic$clase)

# 2.7 Gráfico Sentimientos
ggplot(opencritic, aes(clase, fill = clase)) +
  geom_bar() +
  labs(
    title = "Sentimientos de OpenCritic",
    x = "Sentimiento",
    y = "Cantidad"
  )

# 2.8 Emociones NRC
emociones_oc <- get_nrc_sentiment(opencritic$comentario_traducida)
totales_oc <- colSums(emociones_oc)

# Cambiar nombres a español
names(totales_oc) <- c("Ira", "Anticipación", "Asco", "Miedo", "Alegría", 
                       "Tristeza", "Sorpresa", "Confianza", "Negativo", "Positivo")

par(mar = c(5, 7, 4, 2)) 
barplot(
  totales_oc,
  horiz = TRUE,        
  las = 1,             
  col = "orange",
  main = "Emociones detectadas en OpenCritic",
  xlab = "Frecuencia"
)


# ==============================================================================
# DETECCIÓN DE IA Y MÉTRICAS LINGÜÍSTICAS - STEAM
# ==============================================================================

# 1. Función de clasificación (Escala 1 a 10)
clasificar_ia_steam <- function(indice){
  if(is.na(indice)) return("Desconocido")
  if(indice >= 8){
    return("Muy probable IA")
  } else if(indice >= 6){
    return("Probable IA")
  } else if(indice >= 4){
    return("Dudoso")
  } else {
    return("Humano")
  }
}

# 2. Calcular métricas en Steam (usando la columna 'review')
steam <- steam %>%
  mutate(
    clasificacionIA = sapply(indice_ia, clasificar_ia_steam),
    clasificacionIA = factor(clasificacionIA, 
                             levels = c("Humano", "Dudoso", "Probable IA", "Muy probable IA")),
    caracteres = nchar(review),
    palabras = str_count(review, "\\S+"),
    oraciones = str_count(review, "[.!?]"),
    promedio_palabra = ifelse(palabras > 0, caracteres / palabras, 0)
  )

# 3. Reportes en consola
cat("\n--- DISTRIBUCIÓN DE COMENTARIOS (STEAM) ---\n")
print(table(steam$clasificacionIA))

cat("\n--- PROMEDIO DE PALABRAS POR CATEGORÍA (STEAM) ---\n")
print(aggregate(palabras ~ clasificacionIA, data = steam, FUN = mean))

cat("\n--- LONGITUD MEDIA DE LA PALABRA POR CATEGORÍA (STEAM) ---\n")
print(aggregate(promedio_palabra ~ clasificacionIA, data = steam, FUN = mean))

# 4. Gráficos para Steam
# Gráfico de barras: Distribución
grafico_barras_steam <- ggplot(steam, aes(x = clasificacionIA, fill = clasificacionIA)) +
  geom_bar(color = "black") +
  geom_text(stat = "count", aes(label = after_stat(count)), vjust = -0.5, size = 5, fontface = "bold") +
  scale_fill_brewer(palette = "YlOrRd") + 
  theme_minimal() +
  labs(
    title = "Steam: Clasificación de Comentarios (Humano vs. IA)",
    x = "Categoría Asignada",
    y = "Cantidad de Reseñas"
  ) +
  theme(legend.position = "none")

# Gráfico de cajas: Longitud de reseñas
grafico_cajas_steam <- ggplot(steam, aes(x = clasificacionIA, y = indice_ia, fill = clasificacionIA)) +
  geom_boxplot() +
  scale_fill_brewer(palette = "YlOrRd") +
  theme_minimal() +
  scale_y_continuous(limits = c(1, 10), breaks = 1:10) +
  stat_summary(fun = median, geom = "text", aes(label = after_stat(y)), 
               vjust = -0.5, size = 4.5, fontface = "bold", color = "black") +
  labs(
    title = "Steam: Distribución del Índice de IA por Categoría",
    x = "Clasificación",
    y = "Índice de IA (1 al 10)"
  ) +
  theme(legend.position = "none")

# Mostrar los gráficos
print(grafico_barras_steam)
print(grafico_cajas_steam)



c# ==============================================================================
# DETECCIÓN DE IA Y MÉTRICAS LINGÜÍSTICAS - OPENCRITIC
# ==============================================================================

# 1. Función de clasificación (Escala 1 a 10)
clasificar_ia_oc <- function(indice){
  if(is.na(indice)) return("Desconocido")
  if(indice >= 8){
    return("Muy probable IA")
  } else if(indice >= 6){
    return("Probable IA")
  } else if(indice >= 4){
    return("Dudoso")
  } else {
    return("Humano")
  }
}

# 2. Calcular métricas en OpenCritic (usando la columna 'comentario_traducida')
opencritic <- opencritic %>%
  mutate(
    clasificacionIA = sapply(indice_ia, clasificar_ia_oc),
    clasificacionIA = factor(clasificacionIA, 
                             levels = c("Humano", "Dudoso", "Probable IA", "Muy probable IA")),
    caracteres = nchar(comentario_traducida),
    palabras = str_count(comentario_traducida, "\\S+"),
    oraciones = str_count(comentario_traducida, "[.!?]"),
    promedio_palabra = ifelse(palabras > 0, caracteres / palabras, 0)
  )

# 3. Reportes en consola
cat("\n--- DISTRIBUCIÓN DE COMENTARIOS (OPENCRITIC) ---\n")
print(table(opencritic$clasificacionIA))

cat("\n--- PROMEDIO DE PALABRAS POR CATEGORÍA (OPENCRITIC) ---\n")
print(aggregate(palabras ~ clasificacionIA, data = opencritic, FUN = mean))

cat("\n--- LONGITUD MEDIA DE LA PALABRA POR CATEGORÍA (OPENCRITIC) ---\n")
print(aggregate(promedio_palabra ~ clasificacionIA, data = opencritic, FUN = mean))

# 4. Gráficos para OpenCritic
# Gráfico de barras: Distribución
grafico_barras_oc <- ggplot(opencritic, aes(x = clasificacionIA, fill = clasificacionIA)) +
  geom_bar(color = "black") +
  geom_text(stat = "count", aes(label = after_stat(count)), vjust = -0.5, size = 5, fontface = "bold") +
  scale_fill_brewer(palette = "YlOrRd") + 
  theme_minimal() +
  labs(
    title = "OpenCritic: Clasificación de Comentarios (Humano vs. IA)",
    x = "Categoría Asignada",
    y = "Cantidad de Reseñas"
  ) +
  theme(legend.position = "none")

# Gráfico de cajas: Longitud de reseñas
grafico_dispersion_oc <- ggplot(opencritic, aes(x = clasificacionIA, y = indice_ia, color = clasificacionIA)) +
  geom_jitter(width = 0.2, height = 0.1, alpha = 0.8, size = 2.5) + 
  scale_color_manual(values = c(
    "Humano" = "dodgerblue",       # Azul brillante
    "Dudoso" = "orange",           # Naranja fuerte
    "Probable IA" = "red",         # Rojo intenso
    "Muy probable IA" = "purple"   # Morado oscuro
  )) +
  
  theme_minimal() +
  scale_y_continuous(limits = c(1, 10), breaks = 1:10) +
  labs(
    title = "OpenCritic: Dispersión del índice por categorías",
    x = "Clasificación",
    y = "Índice de IA"
  ) +
  theme(legend.position = "none")
# Mostrar los gráficos
print(grafico_barras_oc)
print(grafico_dispersion_oc)
